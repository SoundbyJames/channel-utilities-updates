// TierBadgeView.swift
// AudioInterleaver
// Badge component to display metadata tier (Tier A vs Tier B)

import SwiftUI

struct TierBadgeView: View {
    let tier: MetadataTier?
    let containerKind: ContainerKind?
    
    var body: some View {
        HStack(spacing: 4) {
            // Container format badge
            if let container = containerKind {
                Text(container.displayName)
                    .font(.caption2)
                    .fontWeight(.medium)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 2)
                    .background(containerColor(container))
                    .foregroundColor(.white)
                    .cornerRadius(4)
            }
            
            // Tier badge
            if let tier = tier {
                HStack(spacing: 2) {
                    Image(systemName: tierIcon(tier))
                        .font(.caption2)
                    Text(tierText(tier))
                        .font(.caption2)
                        .fontWeight(.medium)
                }
                .padding(.horizontal, 6)
                .padding(.vertical, 2)
                .background(tierColor(tier))
                .foregroundColor(.white)
                .cornerRadius(4)
            }
        }
    }
    
    private func tierIcon(_ tier: MetadataTier) -> String {
        switch tier {
        case .bwfGuaranteed:
            return "checkmark.shield.fill"
        case .bestEffort:
            return "checkmark.circle"
        case .none:
            return "xmark.circle"
        }
    }
    
    private func tierText(_ tier: MetadataTier) -> String {
        switch tier {
        case .bwfGuaranteed:
            return "BWF"
        case .bestEffort:
            return "Best Effort"
        case .none:
            return "No Metadata"
        }
    }
    
    private func tierColor(_ tier: MetadataTier) -> Color {
        switch tier {
        case .bwfGuaranteed:
            return .green
        case .bestEffort:
            return .orange
        case .none:
            return .gray
        }
    }
    
    private func containerColor(_ container: ContainerKind) -> Color {
        switch container {
        case .riffWave, .rf64Wave:
            return .blue
        case .aiff, .caf:
            return .purple
        case .flac:
            return .cyan
        case .mp3, .mp4, .ogg:
            return .pink
        default:
            return .gray
        }
    }
}

// MARK: - Compact Version (for table cells)

struct TierBadgeCompact: View {
    let tier: MetadataTier?
    
    var body: some View {
        if let tier = tier {
            HStack(spacing: 2) {
                Circle()
                    .fill(tierColor(tier))
                    .frame(width: 8, height: 8)
                Text(tierAbbreviation(tier))
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            .help(tier.displayName)
        }
    }
    
    private func tierAbbreviation(_ tier: MetadataTier) -> String {
        switch tier {
        case .bwfGuaranteed:
            return "A"
        case .bestEffort:
            return "B"
        case .none:
            return "—"
        }
    }
    
    private func tierColor(_ tier: MetadataTier) -> Color {
        switch tier {
        case .bwfGuaranteed:
            return .green
        case .bestEffort:
            return .orange
        case .none:
            return .gray
        }
    }
}
