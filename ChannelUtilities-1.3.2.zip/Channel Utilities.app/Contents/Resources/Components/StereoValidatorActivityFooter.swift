// StereoValidatorActivityFooter.swift
// AudioInterleaver
// Micro status footer for Stereo Validator tab - always visible, shows activity state, clickable to open log

import SwiftUI

/// A tiny "news ticker" style footer for Stereo Validator that shows current activity status
/// Click to open the full log popover
struct StereoValidatorActivityFooter: View {
    @ObservedObject var viewModel: StereoValidatorViewModel
    @State private var showLogPopover = false
    
    // Fixed height - never changes, never resizable
    private let footerHeight: CGFloat = 22
    
    var body: some View {
        HStack(spacing: 8) {
            // Left: State indicator + state word
            stateIndicator
            
            // Middle: Current action/message (truncated)
            currentMessage
                .lineLimit(1)
                .truncationMode(.middle)
            
            Spacer()
            
            // Right: Progress (if applicable)
            if viewModel.isAnalyzing {
                HStack(spacing: 4) {
                    Text("\(Int(viewModel.analysisProgress * 100))%")
                        .font(.caption2.monospacedDigit())
                        .foregroundColor(.secondary)
                }
            }
            
            // Error badge (if any errors in results)
            let errorCount = viewModel.analysisResults.filter { $0.error != nil }.count
            if errorCount > 0 {
                HStack(spacing: 2) {
                    Image(systemName: "exclamationmark.circle.fill")
                        .foregroundColor(.red)
                    Text("\(errorCount)")
                        .foregroundColor(.red)
                }
                .font(.caption2)
            }
            
            // Details button
            Button(action: { showLogPopover.toggle() }) {
                HStack(spacing: 2) {
                    Text("Details")
                    Image(systemName: "chevron.right")
                        .font(.system(size: 8))
                }
                .font(.caption2)
                .foregroundColor(.secondary)
            }
            .buttonStyle(.plain)
            .help("View full activity log")
        }
        .padding(.horizontal, 12)
        .frame(height: footerHeight)
        .frame(maxWidth: .infinity)
        .background(Color(NSColor.windowBackgroundColor).opacity(0.95))
        .overlay(
            Divider(), alignment: .top
        )
        .contentShape(Rectangle())
        .onTapGesture {
            showLogPopover.toggle()
        }
        .popover(isPresented: $showLogPopover, arrowEdge: .top) {
            StereoValidatorLogPopoverView(viewModel: viewModel)
        }
    }
    
    // MARK: - State Indicator
    
    @ViewBuilder
    private var stateIndicator: some View {
        HStack(spacing: 4) {
            if viewModel.isAnalyzing {
                ProgressView()
                    .scaleEffect(0.5)
                    .frame(width: 10, height: 10)
                Text("Analyzing")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            } else if !viewModel.analysisResults.isEmpty {
                let errorCount = viewModel.analysisResults.filter { $0.error != nil }.count
                if errorCount == 0 {
                    Circle()
                        .fill(Color.green)
                        .frame(width: 6, height: 6)
                    Text("Done")
                        .font(.caption2)
                        .foregroundColor(.green)
                } else {
                    Circle()
                        .fill(Color.orange)
                        .frame(width: 6, height: 6)
                    Text("Done with errors")
                        .font(.caption2)
                        .foregroundColor(.orange)
                }
            } else {
                Circle()
                    .fill(Color.secondary.opacity(0.5))
                    .frame(width: 6, height: 6)
                Text("Ready")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
        }
    }
    
    // MARK: - Current Message
    
    @ViewBuilder
    private var currentMessage: some View {
        if viewModel.isAnalyzing && !viewModel.currentAnalysisFile.isEmpty {
            Text(viewModel.currentAnalysisFile)
                .font(.caption2)
                .foregroundColor(.secondary)
                .help(viewModel.currentAnalysisFile)
        } else if let lastEntry = viewModel.logEntries.last {
            Text(lastEntry.message)
                .font(.caption2)
                .foregroundColor(.secondary)
                .help(lastEntry.message)
        } else {
            Text("No activity")
                .font(.caption2)
                .foregroundColor(.secondary.opacity(0.5))
        }
    }
}


// MARK: - Log Popover View for Stereo Validator

struct StereoValidatorLogPopoverView: View {
    @ObservedObject var viewModel: StereoValidatorViewModel
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Text("Stereo Validator Log")
                    .font(.headline)
                
                Spacer()
                
                if !viewModel.logEntries.isEmpty {
                    Text("\(viewModel.logEntries.count) entries")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(Color(NSColor.controlBackgroundColor))
            
            Divider()
            
            // Log content
            if viewModel.logEntries.isEmpty {
                VStack(spacing: 8) {
                    Image(systemName: "doc.text")
                        .font(.largeTitle)
                        .foregroundColor(.secondary.opacity(0.5))
                    Text("No log entries yet")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding()
            } else {
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 2) {
                            ForEach(viewModel.logEntries) { entry in
                                StereoValidatorLogEntryRow(entry: entry)
                                    .id(entry.id)
                            }
                        }
                        .padding(8)
                    }
                    .onAppear {
                        // Scroll to bottom on appear
                        if let lastEntry = viewModel.logEntries.last {
                            proxy.scrollTo(lastEntry.id, anchor: .bottom)
                        }
                    }
                    .onChange(of: viewModel.logEntries.count) { _ in
                        if let lastEntry = viewModel.logEntries.last {
                            withAnimation {
                                proxy.scrollTo(lastEntry.id, anchor: .bottom)
                            }
                        }
                    }
                }
            }
            
            Divider()
            
            // Footer with actions
            HStack {
                Button("Clear Log") {
                    viewModel.clearLog()
                }
                .buttonStyle(.borderless)
                .foregroundColor(.orange)
                
                Spacer()
                
                Button("Copy Log") {
                    viewModel.copyLogToClipboard()
                }
                .buttonStyle(.bordered)
                
                Button("Save Log...") {
                    viewModel.saveLog()
                }
                .buttonStyle(.bordered)
                
                Button("Close") {
                    dismiss()
                }
                .buttonStyle(.borderedProminent)
            }
            .padding(12)
        }
        .frame(width: 500, height: 350)
    }
}

// MARK: - Log Entry Row for Stereo Validator

struct StereoValidatorLogEntryRow: View {
    let entry: ProcessingLogEntry
    
    var levelColor: Color {
        switch entry.level {
        case .info: return .secondary
        case .success: return .green
        case .warning: return .orange
        case .error: return .red
        }
    }
    
    var body: some View {
        HStack(alignment: .top, spacing: 6) {
            Text("[\(entry.formattedTime)]")
                .foregroundColor(.secondary)
            
            Text("[\(entry.level.rawValue)]")
                .foregroundColor(levelColor)
                .fontWeight(.medium)
            
            Text(entry.message)
                .foregroundColor(.primary)
        }
        .font(.system(.caption, design: .monospaced))
        .textSelection(.enabled)
    }
}

#Preview {
    VStack {
        Spacer()
        StereoValidatorActivityFooter(viewModel: StereoValidatorViewModel())
    }
    .frame(width: 600, height: 400)
}
