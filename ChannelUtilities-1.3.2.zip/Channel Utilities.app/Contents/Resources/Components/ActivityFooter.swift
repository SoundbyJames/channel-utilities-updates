// ActivityFooter.swift
// AudioInterleaver
// Micro status footer - always visible, shows activity state, clickable to open log

import SwiftUI

/// A tiny "news ticker" style footer that shows current activity status
/// Click to open the full log popover
struct ActivityFooter: View {
    @ObservedObject var viewModel: AppViewModel
    @State private var showLogPopover = false
    
    // Fixed height - never changes, never resizable
    private let footerHeight: CGFloat = 22
    
    var body: some View {
        HStack(spacing: 8) {
            // Left: State indicator + state word
            stateIndicator
            
            // Middle: Current action/message (truncated)
            currentMessage
                .lineLimit(1)
                .truncationMode(.middle)
            
            Spacer()
            
            // Right: Progress (if applicable) + Details button
            if viewModel.isScanning || viewModel.isProcessing {
                progressIndicator
            }
            
            // Error/Warning badge (if any)
            if viewModel.errorCount > 0 {
                HStack(spacing: 2) {
                    Image(systemName: "exclamationmark.circle.fill")
                        .foregroundColor(.red)
                    Text("\(viewModel.errorCount)")
                        .foregroundColor(.red)
                }
                .font(.caption2)
            }
            
            // Details button
            Button(action: { showLogPopover.toggle() }) {
                HStack(spacing: 2) {
                    Text("Details")
                    Image(systemName: "chevron.right")
                        .font(.system(size: 8))
                }
                .font(.caption2)
                .foregroundColor(.secondary)
            }
            .buttonStyle(.plain)
            .help("View full activity log")
        }
        .padding(.horizontal, 12)
        .frame(height: footerHeight)
        .frame(maxWidth: .infinity)
        .background(Color(NSColor.windowBackgroundColor).opacity(0.95))
        .overlay(
            Divider(), alignment: .top
        )
        .contentShape(Rectangle())
        .onTapGesture {
            showLogPopover.toggle()
        }
        .popover(isPresented: $showLogPopover, arrowEdge: .top) {
            LogPopoverView(viewModel: viewModel)
        }
    }
    
    // MARK: - State Indicator
    
    @ViewBuilder
    private var stateIndicator: some View {
        HStack(spacing: 4) {
            if viewModel.isScanning {
                ProgressView()
                    .scaleEffect(0.5)
                    .frame(width: 10, height: 10)
                Text("Scanning")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            } else if viewModel.isProcessing {
                ProgressView()
                    .scaleEffect(0.5)
                    .frame(width: 10, height: 10)
                Text("Running")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            } else if viewModel.completedCount > 0 && viewModel.errorCount == 0 {
                Circle()
                    .fill(Color.green)
                    .frame(width: 6, height: 6)
                Text("Done")
                    .font(.caption2)
                    .foregroundColor(.green)
            } else if viewModel.errorCount > 0 {
                Circle()
                    .fill(Color.red)
                    .frame(width: 6, height: 6)
                Text("Error")
                    .font(.caption2)
                    .foregroundColor(.red)
            } else {
                Circle()
                    .fill(Color.secondary.opacity(0.5))
                    .frame(width: 6, height: 6)
                Text("Ready")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
        }
    }
    
    // MARK: - Current Message
    
    @ViewBuilder
    private var currentMessage: some View {
        if let lastEntry = viewModel.logEntries.last {
            Text(lastEntry.message)
                .font(.caption2)
                .foregroundColor(.secondary)
                .help(lastEntry.message)
        } else {
            Text("No activity")
                .font(.caption2)
                .foregroundColor(.secondary.opacity(0.5))
        }
    }
    
    // MARK: - Progress Indicator
    
    @ViewBuilder
    private var progressIndicator: some View {
        if viewModel.isProcessing {
            HStack(spacing: 4) {
                Text("\(Int(viewModel.progress * 100))%")
                    .font(.caption2.monospacedDigit())
                    .foregroundColor(.secondary)
            }
        }
    }
}

// MARK: - Log Popover View

struct LogPopoverView: View {
    @ObservedObject var viewModel: AppViewModel
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Text("Activity Log")
                    .font(.headline)
                
                Spacer()
                
                if !viewModel.logEntries.isEmpty {
                    Text("\(viewModel.logEntries.count) entries")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(Color(NSColor.controlBackgroundColor))
            
            Divider()
            
            // Log content
            if viewModel.logEntries.isEmpty {
                VStack(spacing: 8) {
                    Image(systemName: "doc.text")
                        .font(.largeTitle)
                        .foregroundColor(.secondary.opacity(0.5))
                    Text("No log entries yet")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding()
            } else {
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 2) {
                            ForEach(viewModel.logEntries) { entry in
                                ActivityLogEntryRow(entry: entry)
                                    .id(entry.id)
                            }
                        }
                        .padding(8)
                    }
                    .onAppear {
                        // Scroll to bottom on appear
                        if let lastEntry = viewModel.logEntries.last {
                            proxy.scrollTo(lastEntry.id, anchor: .bottom)
                        }
                    }
                    .onChange(of: viewModel.logEntries.count) { _ in
                        if let lastEntry = viewModel.logEntries.last {
                            withAnimation {
                                proxy.scrollTo(lastEntry.id, anchor: .bottom)
                            }
                        }
                    }
                }
            }
            
            Divider()
            
            // Footer with actions
            HStack {
                Button("Clear Log") {
                    viewModel.clearLogs()
                }
                .buttonStyle(.borderless)
                .foregroundColor(.orange)
                
                Spacer()
                
                Button("Copy Log") {
                    viewModel.copyLogToClipboard()
                }
                .buttonStyle(.bordered)
                
                Button("Save Log...") {
                    viewModel.saveLogToFile()
                }
                .buttonStyle(.bordered)
                
                Button("Close") {
                    dismiss()
                }
                .buttonStyle(.borderedProminent)
            }
            .padding(12)
        }
        .frame(width: 500, height: 350)
    }
}

// MARK: - Log Entry Row (for popover - renamed to avoid conflict with PolyToolsTabView)

struct ActivityLogEntryRow: View {
    let entry: ProcessingLogEntry
    
    var levelColor: Color {
        switch entry.level {
        case .info: return .secondary
        case .success: return .green
        case .warning: return .orange
        case .error: return .red
        }
    }
    
    var body: some View {
        HStack(alignment: .top, spacing: 6) {
            Text("[\(entry.formattedTime)]")
                .foregroundColor(.secondary)
            
            Text("[\(entry.level.rawValue)]")
                .foregroundColor(levelColor)
                .fontWeight(.medium)
            
            Text(entry.message)
                .foregroundColor(.primary)
        }
        .font(.system(.caption, design: .monospaced))
        .textSelection(.enabled)
    }
}

#Preview {
    VStack {
        Spacer()
        ActivityFooter(viewModel: AppViewModel())
    }
    .frame(width: 600, height: 400)
}
