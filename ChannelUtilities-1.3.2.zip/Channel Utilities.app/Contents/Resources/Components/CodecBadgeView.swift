// CodecBadgeView.swift
// AudioInterleaver
// Badge showing codec type (PCM/Lossless/Lossy) for multi-format support

import SwiftUI

struct CodecBadgeView: View {
    let codecType: CodecType
    
    var body: some View {
        HStack(spacing: 3) {
            Circle()
                .fill(badgeColor)
                .frame(width: 6, height: 6)
            
            Text(codecType.displayName)
                .font(.caption2)
                .fontWeight(.medium)
        }
        .padding(.horizontal, 6)
        .padding(.vertical, 2)
        .background(badgeColor.opacity(0.15))
        .cornerRadius(4)
    }
    
    private var badgeColor: Color {
        switch codecType {
        case .pcm:
            return .blue
        case .lossless:
            return .green
        case .lossy:
            return .orange
        case .unknown:
            return .gray
        }
    }
}
