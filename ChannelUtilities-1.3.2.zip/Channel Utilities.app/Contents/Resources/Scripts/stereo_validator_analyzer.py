#!/usr/bin/env python3
"""
Stereo Validator Analyzer
Detects dual mono vs true stereo vs near mono vs broken stereo
Uses soundfile (libsndfile) for proper BWF/24-bit support
"""

import sys
import json
import argparse
import numpy as np
import soundfile as sf
from scipy import signal

def estimate_lag(L, R, sr, lag_window_ms):
    """
    Estimate lag between L and R channels within small window.
    Uses correct math: small lag window around zero, explicit axis tracking.
    """
    max_lag_samples = int(sr * lag_window_ms / 1000.0)  # e.g., ±1ms = ±48 samples @ 48kHz
    
    if max_lag_samples == 0:
        # No lag window, just compute correlation at zero lag
        corr = np.corrcoef(L, R)[0, 1]
        return 0.0, corr
    
    # Compute correlation for lags in [-max_lag_samples ... +max_lag_samples]
    lags = np.arange(-max_lag_samples, max_lag_samples + 1)
    correlations = []
    
    for lag in lags:
        if lag == 0:
            corr = np.corrcoef(L, R)[0, 1]
        elif lag > 0:
            # R is ahead of L
            if len(L) > lag:
                corr = np.corrcoef(L[:-lag], R[lag:])[0, 1]
            else:
                corr = 0.0
        else:
            # L is ahead of R
            if len(R) > -lag:
                corr = np.corrcoef(L[-lag:], R[:lag])[0, 1]
            else:
                corr = 0.0
        
        correlations.append(corr)
    
    # Find max correlation and its lag
    max_corr_idx = np.argmax(np.abs(correlations))
    max_correlation = correlations[max_corr_idx]
    lag_ms = lags[max_corr_idx] * 1000.0 / sr
    
    return lag_ms, max_correlation


def analyze_stereo_file(filepath, options):
    """
    Analyze a single stereo WAV file.
    Uses windowing (non-silent windows) with median aggregation.
    """
    try:
        # Load audio using soundfile (NOT scipy.io.wavfile)
        audio, sr = sf.read(filepath, dtype='float32')
        
        # Get file info
        info = sf.info(filepath)
        duration = len(audio) / sr
        
        # Try to get bit depth safely
        bit_depth = 16  # Default
        try:
            if hasattr(info, 'subtype_info') and isinstance(info.subtype_info, dict):
                bit_depth = info.subtype_info.get('bit_depth', 16)
            elif hasattr(info, 'subtype'):
                # Parse from subtype string (e.g., 'PCM_24')
                subtype_str = str(info.subtype)
                if '24' in subtype_str:
                    bit_depth = 24
                elif '32' in subtype_str:
                    bit_depth = 32
        except:
            bit_depth = 16
        
        # Check channel count
        if len(audio.shape) == 1 or (len(audio.shape) == 2 and audio.shape[1] == 1):
            # Single-channel mono file
            return {
                "filepath": filepath,
                "classification": "TRUE_MONO",
                "correlation": 0.0,
                "confidence": 100.0,
                "lag_ms": 0.0,
                "mid_side_ratio": 0.0,
                "rms_diff": 0.0,
                "duration_seconds": duration,
                "sample_rate": sr,
                "bit_depth": bit_depth,
                "error": None  # Not an error, just mono
            }
        elif len(audio.shape) != 2 or audio.shape[1] != 2:
            # Unsupported format (3+ channels, etc.)
            return {
                "filepath": filepath,
                "classification": "UNSUPPORTED",
                "correlation": 0.0,
                "confidence": 0.0,
                "lag_ms": 0.0,
                "mid_side_ratio": 0.0,
                "rms_diff": 0.0,
                "duration_seconds": duration,
                "sample_rate": sr,
                "bit_depth": bit_depth,
                "error": "Unsupported format (channels: {})".format(audio.shape[1] if len(audio.shape) > 1 else 0)
            }
        
        L = audio[:, 0]
        R = audio[:, 1]
        
        # Find non-silent windows (0.5-2s windows, overlapping)
        window_size_samples = int(sr * 1.0)  # 1 second windows
        hop_size = window_size_samples // 2   # 50% overlap
        
        window_correlations = []
        window_rms_diffs = []
        window_ms_ratios = []
        
        for start in range(0, len(L) - window_size_samples, hop_size):
            window_L = L[start:start + window_size_samples]
            window_R = R[start:start + window_size_samples]
            
            # Skip silent windows (dBFS check is more reliable)
            window_L_rms = np.sqrt(np.mean(window_L ** 2))
            window_R_rms = np.sqrt(np.mean(window_R ** 2))
            window_L_dbfs = 20 * np.log10(window_L_rms) if window_L_rms > 1e-12 else -120.0
            window_R_dbfs = 20 * np.log10(window_R_rms) if window_R_rms > 1e-12 else -120.0
            
            # Skip if both channels are silent (below -100 dBFS)
            if window_L_dbfs <= -100.0 and window_R_dbfs <= -100.0:
                continue
            
            # Compute metrics for this window
            corr = np.corrcoef(window_L, window_R)[0, 1]
            rms_diff = np.sqrt(np.mean((window_L - window_R) ** 2))
            
            Mid = (window_L + window_R) / 2
            Side = (window_L - window_R) / 2
            ms_ratio = np.mean(Side ** 2) / (np.mean(Mid ** 2) + 1e-10)
            
            window_correlations.append(corr)
            window_rms_diffs.append(rms_diff)
            window_ms_ratios.append(ms_ratio)
        
        # Aggregate with median (robust to outliers)
        if not window_correlations:
            # All windows were silent
            return {
                "filepath": filepath,
                "classification": "UNSUPPORTED",
                "correlation": 0.0,
                "confidence": 0.0,
                "lag_ms": 0.0,
                "mid_side_ratio": 0.0,
                "rms_diff": 0.0,
                "duration_seconds": duration,
                "sample_rate": sr,
                "bit_depth": bit_depth,
                "error": "File appears to be silent"
            }
        
        final_correlation = np.median(window_correlations)
        final_rms_diff = np.median(window_rms_diffs)
        final_ms_ratio = np.median(window_ms_ratios)
        
        # Lag estimation (on representative windows, not full file for performance)
        # Use downsampled envelope for very long files
        if len(L) > sr * 600:  # > 10 minutes
            # Downsample to 1kHz for lag estimation
            downsample_factor = sr // 1000
            L_env = L[::downsample_factor]
            R_env = R[::downsample_factor]
            lag_ms, _ = estimate_lag(L_env, R_env, 1000, options['lag_window_ms'])
        else:
            # Use full file for shorter files
            lag_ms, _ = estimate_lag(L, R, sr, options['lag_window_ms'])
        
        # Calculate dBFS for both channels (for SILENT and ONE-SIDED detection)
        L_rms = np.sqrt(np.mean(L ** 2))
        R_rms = np.sqrt(np.mean(R ** 2))
        L_dbfs = 20 * np.log10(L_rms) if L_rms > 1e-12 else -120.0
        R_dbfs = 20 * np.log10(R_rms) if R_rms > 1e-12 else -120.0
        
        # Calculate level difference in dB
        level_diff_db = abs(L_dbfs - R_dbfs)
        
        # Gain-compensated similarity test for "heavy-sided dual mono"
        # If correlation is very high but RMS diff is significant, check if it's just a gain mismatch
        gain_compensated_corr = None
        if abs(final_correlation) >= 0.9995 and level_diff_db > 1.5 and level_diff_db < 30.0:
            # Normalize one channel to match the other's level, then check correlation
            if L_rms > R_rms:
                gain = R_rms / (L_rms + 1e-12)
                L_normalized = L * gain
                gain_compensated_corr = np.corrcoef(L_normalized, R)[0, 1]
            else:
                gain = L_rms / (R_rms + 1e-12)
                R_normalized = R * gain
                gain_compensated_corr = np.corrcoef(L, R_normalized)[0, 1]
        
        # Classification
        classification = classify(
            final_correlation,
            final_rms_diff,
            final_ms_ratio,
            lag_ms,
            L_dbfs,
            R_dbfs,
            level_diff_db,
            gain_compensated_corr,
            options
        )
        
        # Confidence scoring
        confidence = calculate_confidence(
            classification,
            final_correlation,
            final_ms_ratio,
            lag_ms,
            options
        )
        
        return {
            "filepath": filepath,
            "classification": classification,
            "correlation": float(final_correlation),
            "confidence": float(confidence),
            "lag_ms": float(lag_ms),
            "mid_side_ratio": float(final_ms_ratio),
            "rms_diff": float(final_rms_diff),
            "duration_seconds": float(duration),
            "sample_rate": int(sr),
            "bit_depth": int(bit_depth),
            "error": None
        }
        
    except Exception as e:
        return {
            "filepath": filepath,
            "classification": "UNSUPPORTED",
            "correlation": 0.0,
            "confidence": 0.0,
            "lag_ms": 0.0,
            "mid_side_ratio": 0.0,
            "rms_diff": 0.0,
            "duration_seconds": 0.0,
            "sample_rate": 0,
            "bit_depth": 0,
            "error": str(e)
        }


def classify(corr, rms_diff, ms_ratio, lag_ms, L_dbfs, R_dbfs, level_diff_db, gain_compensated_corr, options):
    """Classify based on thresholds.
    
    Args:
        corr: Pearson correlation coefficient
        rms_diff: RMS difference between channels
        ms_ratio: Mid/Side energy ratio
        lag_ms: Lag in milliseconds
        L_dbfs: Left channel level in dBFS
        R_dbfs: Right channel level in dBFS
        level_diff_db: Level difference between channels in dB
        gain_compensated_corr: Correlation after gain compensation (if computed)
        options: Configuration options
    """
    dual_thresh = options['dual_mono_threshold']
    near_thresh = options['near_mono_threshold']
    small_lag = options['small_lag_ms']
    big_lag = options['big_lag_ms']
    one_sided_db = options.get('one_sided_db', 50.0)  # Default 50 dB threshold
    
    # SILENT detection (both channels at or below -100 dBFS)
    if L_dbfs <= -100.0 and R_dbfs <= -100.0:
        return "SILENT"
    
    # ONE-SIDED detection (one channel significantly louder than the other)
    min_db = min(L_dbfs, R_dbfs)
    max_db = max(L_dbfs, R_dbfs)
    if max_db - min_db > one_sided_db and max_db > -90.0:
        # Only flag if the louder channel is above very low level
        return "ONE_SIDED_R" if R_dbfs > L_dbfs else "ONE_SIDED_L"
    
    # DUAL_MONO (handles polarity-inverted via abs(corr))
    if (abs(corr) >= dual_thresh and
        abs(lag_ms) <= small_lag and
        ms_ratio < 0.01):
        return "DUAL_MONO"
    
    # DUAL_MONO_GAIN_MISMATCH: High correlation but level difference (gain-compensated test)
    # Check BEFORE NEAR_MONO to catch this edge case
    if (abs(corr) >= 0.9995 and  # Very high correlation
        abs(lag_ms) <= small_lag and
        level_diff_db > 1.5 and  # Meaningful level difference (> 1.5 dB)
        level_diff_db < 30.0 and  # But not extreme (< 30 dB, which would be one-sided)
        gain_compensated_corr is not None and
        abs(gain_compensated_corr) >= 0.995):  # After gain compensation, still very high correlation
        return "DUAL_MONO_GAIN_MISMATCH"
    
    # NEAR_MONO
    elif (abs(corr) >= near_thresh and
          abs(corr) < dual_thresh and
          abs(lag_ms) <= small_lag):
        return "NEAR_MONO"
    
    # BROKEN (low correlation alone is NOT sufficient - must be phasey or large lag)
    elif (corr <= -0.2 or  # Strongly negative (phasey)
          abs(lag_ms) >= big_lag):  # Large lag (wiring issue)
        return "BROKEN"
    
    # TRUE_STEREO (default)
    else:
        return "TRUE_STEREO"


def calculate_confidence(classification, corr, ms_ratio, lag_ms, options):
    """Calculate confidence score (0-100) for sorting/prioritization only."""
    dual_thresh = options['dual_mono_threshold']
    near_thresh = options['near_mono_threshold']
    big_lag = options['big_lag_ms']
    
    if classification == "DUAL_MONO":
        # High confidence when corr ~1 and side≈0
        confidence = (abs(corr) * 0.7 + (1.0 - min(ms_ratio * 100, 1.0)) * 0.3) * 100
        return min(max(confidence, 0), 100)
    
    elif classification == "DUAL_MONO_GAIN_MISMATCH":
        # High confidence when gain-compensated correlation is very high
        # Slightly lower than perfect dual mono due to the level mismatch
        confidence = abs(corr) * 85.0  # Scale to ~85% for very high correlation
        return min(max(confidence, 0), 100)
    
    elif classification == "NEAR_MONO":
        # Confidence drops as corr moves away from thresholds
        distance_from_dual = abs(corr - dual_thresh)
        distance_from_near = abs(corr - near_thresh)
        distance = min(distance_from_dual, distance_from_near)
        confidence = (1.0 - min(distance / 0.05, 1.0)) * 100
        return min(max(confidence, 0), 100)
    
    elif classification == "TRUE_STEREO":
        # Confidence tied to side ratio and lack of negative corr
        side_component = min(ms_ratio * 10, 1.0) * 0.6
        corr_component = (1.0 if corr > 0 else 0) * 0.4
        confidence = (side_component + corr_component) * 100
        return min(max(confidence, 0), 100)
    
    elif classification in ["ONE_SIDED_L", "ONE_SIDED_R"]:
        # High confidence for one-sided (clear level difference)
        confidence = 85.0  # Fixed high confidence for one-sided detection
        return min(max(confidence, 0), 100)
    
    elif classification == "SILENT":
        # Very high confidence for silent files
        return 100.0
    
    elif classification == "BROKEN":
        # High confidence when clearly problematic
        if corr <= -0.2:
            confidence = abs(corr) * 100  # e.g., -0.5 → 50%
        elif abs(lag_ms) >= big_lag:
            confidence = min(abs(lag_ms) / big_lag, 1.0) * 100
        else:
            confidence = 50.0
        return min(max(confidence, 0), 100)
    
    else:  # UNSUPPORTED
        return 0.0


def main():
    parser = argparse.ArgumentParser(description='Analyze stereo WAV files for dual mono detection')
    parser.add_argument('files', nargs='+', help='WAV files to analyze')
    parser.add_argument('--json_out', required=True, help='Output JSON file path')
    parser.add_argument('--dual_mono_threshold', type=float, default=0.995, help='Dual mono correlation threshold')
    parser.add_argument('--near_mono_threshold', type=float, default=0.95, help='Near mono correlation threshold')
    parser.add_argument('--small_lag_ms', type=float, default=1.0, help='Small lag window (ms)')
    parser.add_argument('--big_lag_ms', type=float, default=5.0, help='Big lag threshold (ms)')
    parser.add_argument('--one_sided_db', type=float, default=50.0, help='One-sided detection threshold (dB)')
    
    args = parser.parse_args()
    
    options = {
        'dual_mono_threshold': args.dual_mono_threshold,
        'near_mono_threshold': args.near_mono_threshold,
        'small_lag_ms': args.small_lag_ms,
        'lag_window_ms': args.small_lag_ms,  # Alias for lag estimation
        'big_lag_ms': args.big_lag_ms,
        'one_sided_db': args.one_sided_db
    }
    
    results = []
    total_files = len(args.files)
    
    for index, filepath in enumerate(args.files):
        # Report progress to stderr (Swift reads this in real-time)
        # Format: PROGRESS:current:total:filename
        import os
        filename = os.path.basename(filepath)
        print(f"PROGRESS:{index + 1}:{total_files}:{filename}", file=sys.stderr, flush=True)
        
        result = analyze_stereo_file(filepath, options)
        results.append(result)
    
    # Write JSON output
    with open(args.json_out, 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"Analyzed {len(results)} files, wrote results to {args.json_out}")


if __name__ == "__main__":
    main()

