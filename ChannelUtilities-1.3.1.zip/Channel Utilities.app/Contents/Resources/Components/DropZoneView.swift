// DropZoneView.swift
// AudioInterleaver
// NSView-based drag and drop that works reliably on all macOS versions

import SwiftUI
import AppKit

/// A view that provides reliable drag-and-drop functionality using NSView
struct DropZoneView: NSViewRepresentable {
    @Binding var isDragTargeted: Bool
    let onDrop: ([URL]) -> Void
    
    func makeNSView(context: Context) -> DropZoneNSView {
        let view = DropZoneNSView()
        view.onDragEnter = { [self] in
            DispatchQueue.main.async {
                self.isDragTargeted = true
                print("🎯 NSView DRAG ENTER")
            }
        }
        view.onDragExit = { [self] in
            DispatchQueue.main.async {
                self.isDragTargeted = false
                print("🎯 NSView DRAG EXIT")
            }
        }
        view.onDrop = { urls in
            DispatchQueue.main.async {
                self.isDragTargeted = false
                print("📦 NSView DROP: \(urls.count) items")
                self.onDrop(urls)
            }
        }
        return view
    }
    
    func updateNSView(_ nsView: DropZoneNSView, context: Context) {
        // No updates needed
    }
}

/// NSView subclass that handles drag and drop
class DropZoneNSView: NSView {
    var onDragEnter: (() -> Void)?
    var onDragExit: (() -> Void)?
    var onDrop: (([URL]) -> Void)?
    
    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        registerForDraggedTypes([.fileURL])
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        registerForDraggedTypes([.fileURL])
    }
    
    override func draggingEntered(_ sender: NSDraggingInfo) -> NSDragOperation {
        print("🎯 NSView draggingEntered called")
        onDragEnter?()
        return .copy
    }
    
    override func draggingExited(_ sender: NSDraggingInfo?) {
        print("🎯 NSView draggingExited called")
        onDragExit?()
    }
    
    override func draggingEnded(_ sender: NSDraggingInfo) {
        print("🎯 NSView draggingEnded called")
        onDragExit?()
    }
    
    override func performDragOperation(_ sender: NSDraggingInfo) -> Bool {
        print("📦 NSView performDragOperation called")
        guard let items = sender.draggingPasteboard.pasteboardItems else {
            return false
        }
        
        var urls: [URL] = []
        for item in items {
            if let urlString = item.string(forType: .fileURL),
               let url = URL(string: urlString) {
                urls.append(url)
            }
        }
        
        if !urls.isEmpty {
            onDrop?(urls)
            return true
        }
        return false
    }
}
