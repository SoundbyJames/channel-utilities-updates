// AudioPreviewPanel.swift
// AudioInterleaver
// Preview panel with waveform visualization and playback controls

import SwiftUI

struct AudioPreviewPanel: View {
    @ObservedObject var playbackManager: PlaybackManager
    // Waveform state is now stored in PlaybackManager for persistence across tab switches
    
    // MARK: - Layout Constants (Phase 3: Fit-to-Pane)
    
    /// Reserved height for non-waveform elements (header + channel buttons + transport)
    private let reservedHeight: CGFloat = 90
    
    /// Minimum readable lane height - below this, lanes get hard to distinguish
    private let minReadableLaneHeight: CGFloat = 10
    
    /// Absolute minimum lane height - below this, switch to composite fallback
    private let absoluteMinLaneHeight: CGFloat = 4
    
    /// Whether to show multi-channel stacked waveforms
    /// Shows for stereo (2ch) and surround (5.1/7.1) - only mono stays single lane
    private var showMultiChannelWaveform: Bool {
        // Show multi-channel for stereo (2ch) and surround (>2ch)
        // Only mono (1ch) uses single waveform
        if playbackManager.canAuditionChannels {
            return playbackManager.multiChannelWaveformData.count >= 2
        }
        return false
    }
    
    /// Waveform display mode based on available space
    private enum WaveformDisplayMode {
        case normal      // Lanes ≥10pt - full readable lanes
        case condensed   // Lanes 4-10pt - thin lanes + hint
        case fallback    // Lanes <4pt - single composite + channel count
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Header with preview mode toggle
            HStack(spacing: 12) {
                HStack(spacing: 4) {
                    Text("PREVIEW")
                        .font(.caption)
                        .fontWeight(.semibold)
                        .foregroundColor(.secondary)
                    Image(systemName: "arrow.up.and.down")
                        .font(.system(size: 8))
                        .foregroundColor(.secondary.opacity(0.5))
                }
                .help("Drag divider above to resize preview panel")
                
                // Preview mode toggle - only show when channel audition is NOT available
                // When channel buttons are shown, they replace this functionality
                if playbackManager.canTogglePreviewMode && !playbackManager.canAuditionChannels {
                    previewModeToggle
                }
                
                Spacer()
                
                // Output mode label
                if playbackManager.hasFile {
                    Text("OUTPUT: Standard")
                        .font(.caption2)
                        .foregroundColor(.secondary.opacity(0.7))
                }
                
                if playbackManager.hasFile {
                    Button(action: { playbackManager.stopAndClear() }) {
                        Text("Clear")
                            .font(.caption)
                    }
                    .buttonStyle(.borderless)
                    .foregroundColor(.secondary)
                }
            }
            .padding(.horizontal, 12)
            .padding(.top, 8)
            .padding(.bottom, 6)
            
            // Channel audition buttons (when available)
            if playbackManager.canAuditionChannels && playbackManager.hasFile {
                channelAuditionButtons
                    .padding(.horizontal, 12)
                    .padding(.bottom, 6)
            }
            
            if playbackManager.hasFile {
                // Phase 3: Adaptive waveform with fit-to-pane and three-tier fallback
                // Waveform section - uses available space efficiently
                waveformSection
                    .padding(.horizontal, 12)
                
                // Transport controls row - fixed at bottom
                HStack(spacing: 12) {
                    // Play/Pause button
                    Button(action: { playbackManager.togglePlayPause() }) {
                        Image(systemName: playbackManager.isPlaying ? "pause.fill" : "play.fill")
                            .font(.system(size: 20))
                            .frame(width: 36, height: 36)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .disabled(!playbackManager.isLoaded)
                    .help(playbackManager.isPlaying ? "Pause (Space)" : "Play (Space)")
                    
                    // Stop button
                    Button(action: { playbackManager.stop() }) {
                        Image(systemName: "stop.fill")
                            .font(.system(size: 14))
                            .frame(width: 28, height: 28)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .disabled(!playbackManager.isLoaded)
                    .help("Stop")
                    
                    // File name
                    Text(playbackManager.currentFileName)
                        .font(.caption)
                        .lineLimit(1)
                        .truncationMode(.middle)
                        .foregroundColor(.primary)
                    
                    Spacer()
                    
                    // Time display - real-time
                    TimelineView(.animation(minimumInterval: 0.1)) { _ in
                        Text("\(formatTime(playbackManager.engine.currentTime)) / \(formatTime(playbackManager.engine.duration))")
                            .font(.caption.monospacedDigit())
                            .foregroundColor(.secondary)
                    }
                    
                    // File info (sample rate, bit depth)
                    if !playbackManager.currentFileInfo.isEmpty {
                        Text(playbackManager.currentFileInfo)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                
                // Error message
                if playbackManager.hasError {
                    HStack {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .foregroundColor(.orange)
                        Text(playbackManager.errorMessage)
                            .font(.caption)
                            .foregroundColor(.orange)
                        Spacer()
                    }
                    .padding(.horizontal, 12)
                    .padding(.bottom, 8)
                }
            } else {
                // Empty state
                VStack(spacing: 8) {
                    Image(systemName: "waveform")
                        .font(.system(size: 32))
                        .foregroundColor(.secondary.opacity(0.5))
                    Text("Click a row to preview")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                .frame(height: 80)
                .frame(maxWidth: .infinity)
            }
        }
        .background(Color(NSColor.controlBackgroundColor))
        .cornerRadius(8)
        .onChange(of: playbackManager.currentFileURL) { newURL in
            if let url = newURL {
                playbackManager.loadWaveform(from: url)
            } else {
                playbackManager.waveformData = []
                playbackManager.multiChannelWaveformData = []
            }
        }
        // Also reload waveform when preview mode changes (stereo vs L only)
        .onChange(of: playbackManager.previewMode) { _ in
            if let url = playbackManager.currentFileURL {
                playbackManager.loadWaveform(from: url)
            }
        }
        // Reload waveform when channel audition changes (but not during re-audition for routing change)
        .onChange(of: playbackManager.selectedChannelTag) { _ in
            if playbackManager.shouldReloadWaveform, let url = playbackManager.currentFileURL {
                playbackManager.loadWaveform(from: url)
            }
        }
    }
    
    // MARK: - Preview Mode Toggle (Dynamic Segmented Style)
    
    private var previewModeToggle: some View {
        HStack(spacing: 0) {
            ForEach(playbackManager.availablePreviewModes, id: \.self) { mode in
                Button(action: {
                    if playbackManager.previewMode != mode && !playbackManager.isGeneratingStereoPreview {
                        print("[AudioPreviewPanel] Toggle clicked: switching to \(mode)")
                        Task {
                            await playbackManager.setPreviewMode(mode)
                        }
                    }
                }) {
                    HStack(spacing: 4) {
                        if (mode == .postInterleave || mode == .postInterleaveSurround || mode == .leftChannel || mode == .rightChannel || mode == .centerChannel) && playbackManager.isGeneratingStereoPreview && playbackManager.previewMode != mode {
                            ProgressView()
                                .scaleEffect(0.6)
                                .frame(width: 12, height: 12)
                        } else {
                            Image(systemName: mode.icon)
                                .font(.caption2)
                        }
                        Text(mode.displayName)
                            .font(.caption)
                            .fontWeight(.medium)
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(
                        RoundedRectangle(cornerRadius: 5)
                            .fill(playbackManager.previewMode == mode ? Color.accentColor : Color.clear)
                    )
                    .foregroundColor(playbackManager.previewMode == mode ? .white : .secondary)
                }
                .buttonStyle(.plain)
                .disabled(playbackManager.isGeneratingStereoPreview)
            }
        }
        .background(
            RoundedRectangle(cornerRadius: 6)
                .fill(Color(NSColor.separatorColor).opacity(0.3))
        )
        .help("Toggle between available preview modes")
    }
    
    // MARK: - Channel Audition Buttons (Unified Preview Control)
    
    /// Dynamic label for the Mix button - shows "Stereo" for stereo layout, "Mix" for surround
    private var mixButtonLabel: String {
        // Check if we're in stereo mode (2 channels: L and R only)
        let tags = playbackManager.availableChannelTags
        if tags.count == 2 && tags.contains("L") && tags.contains("R") {
            return "Stereo"
        }
        return "Mix"
    }
    
    private var channelAuditionButtons: some View {
        HStack(spacing: 6) {
            // Label with hint
            Text("▶ Preview:")
                .font(.caption)
                .fontWeight(.medium)
                .foregroundColor(.secondary)
            
            // Mix/Stereo button - behavior depends on mode:
            // De-interleave: plays original multichannel source
            // Interleave: generates and plays the composite mix (what we'll create)
            Button(action: {
                Task {
                    // Always force reload the correct "mix" file
                    // This handles both modes and ensures we get the right audio
                    await playbackManager.reloadSourceFile()
                }
            }) {
                HStack(spacing: 4) {
                    Image(systemName: "speaker.wave.3")
                        .font(.system(size: 10))
                    Text(mixButtonLabel)
                        .font(.caption)
                        .fontWeight(.medium)
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 5)
                .background(
                    RoundedRectangle(cornerRadius: 5)
                        .fill(playbackManager.selectedChannelTag == nil && (playbackManager.previewMode == .postInterleaveSurround || playbackManager.previewMode == .postInterleave || playbackManager.previewMode == .source) ? Color.accentColor : Color(NSColor.separatorColor).opacity(0.4))
                )
                .foregroundColor(playbackManager.selectedChannelTag == nil && (playbackManager.previewMode == .postInterleaveSurround || playbackManager.previewMode == .postInterleave || playbackManager.previewMode == .source) ? .white : .primary)
            }
            .buttonStyle(.plain)
            .disabled(playbackManager.isGeneratingStereoPreview)
            .help("Preview full \(mixButtonLabel.lowercased())")
            
            // Separator
            Rectangle()
                .fill(Color.secondary.opacity(0.3))
                .frame(width: 1, height: 16)
                .padding(.horizontal, 4)
            
            // Individual channel buttons with speaker icon
            ForEach(playbackManager.availableChannelTags, id: \.self) { tag in
                Button(action: {
                    Task {
                        await playbackManager.auditionChannel(tag)
                    }
                }) {
                    HStack(spacing: 3) {
                        Image(systemName: playbackManager.previewRouting == .speakerRouted ? "speaker.wave.2" : "speaker.wave.1")
                            .font(.system(size: 9))
                        Text(tag)
                            .font(.caption)
                            .fontWeight(.semibold)
                    }
                    .padding(.horizontal, 8)
                    .padding(.vertical, 5)
                    .background(
                        RoundedRectangle(cornerRadius: 5)
                            .fill(playbackManager.selectedChannelTag == tag ? Color.orange : Color(NSColor.separatorColor).opacity(0.4))
                    )
                    .foregroundColor(playbackManager.selectedChannelTag == tag ? .white : .primary)
                }
                .buttonStyle(.plain)
                .disabled(playbackManager.isGeneratingStereoPreview)
                .help(playbackManager.previewRouting == .speakerRouted ? 
                      "Preview \(tag) channel (speaker-routed)" : 
                      "Preview \(tag) channel (mono)")
            }
            
            Spacer()
            
            // Loading indicator
            if playbackManager.isGeneratingStereoPreview {
                HStack(spacing: 4) {
                    ProgressView()
                        .scaleEffect(0.6)
                        .frame(width: 14, height: 14)
                    Text("Loading...")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                }
                .transition(.identity)  // Disable animation to prevent bouncing/vibrating
                .animation(.none, value: playbackManager.isGeneratingStereoPreview)
            }
            
            // Preview Routing Toggle (for stereo AND surround layouts - 2+ channels)
            // Only active when a channel is soloed - Mix doesn't use this
            if playbackManager.availableChannelTags.count >= 2 {
                HStack(spacing: 4) {
                    Text("Solo Routing:")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    Picker("", selection: $playbackManager.previewRouting) {
                        ForEach(PlaybackManager.PreviewRouting.allCases, id: \.self) { mode in
                            Text(mode.rawValue).tag(mode)
                        }
                    }
                    .pickerStyle(.menu)
                    .frame(width: 150)
                    .disabled(playbackManager.selectedChannelTag == nil)
                    .opacity(playbackManager.selectedChannelTag == nil ? 0.5 : 1.0)
                    .onChange(of: playbackManager.previewRouting) { _ in
                        // Re-audition current channel with new routing mode
                        if playbackManager.selectedChannelTag != nil {
                            Task {
                                // Force re-audition by clearing and re-selecting
                                await playbackManager.reAuditionCurrentChannel()
                            }
                        }
                    }
                    
                    // Inline hint when Mix is selected (control is disabled)
                    if playbackManager.selectedChannelTag == nil {
                        Text("(for channel preview)")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                    }
                }
                .help(playbackManager.selectedChannelTag == nil ? 
                      "Select a channel to enable routing options" : 
                      playbackManager.previewRouting.description)
            }
        }
    }
    
    // MARK: - Waveform Section (Phase 3: Adaptive Fit-to-Pane)
    
    @ViewBuilder
    private var waveformSection: some View {
        let channelCount = max(1, playbackManager.multiChannelWaveformData.count)
        
        if showMultiChannelWaveform {
            // Multi-channel: use GeometryReader for adaptive sizing
            GeometryReader { geometry in
                let availableHeight = geometry.size.height
                let calculatedLaneHeight = availableHeight / CGFloat(channelCount)
                
                // Determine display mode based on available space
                let displayMode: WaveformDisplayMode = {
                    if calculatedLaneHeight >= minReadableLaneHeight {
                        return .normal
                    } else if calculatedLaneHeight >= absoluteMinLaneHeight {
                        return .condensed
                    } else {
                        return .fallback
                    }
                }()
                
                VStack(spacing: 0) {
                    switch displayMode {
                    case .normal:
                        // Normal mode: fill available space with readable lanes
                        multiChannelWaveformView
                            .frame(height: availableHeight)
                        
                    case .condensed:
                        // Condensed mode: thin lanes, still per-channel
                        multiChannelWaveformView
                            .frame(height: availableHeight - 16)  // Leave room for hint
                        Text("Expand preview for larger waveforms")
                            .font(.caption2)
                            .foregroundColor(.secondary.opacity(0.7))
                            .frame(height: 14)
                        
                    case .fallback:
                        // Fallback mode: single composite waveform + channel count badge
                        waveformView
                            .frame(height: min(50, availableHeight - 16))
                        HStack(spacing: 8) {
                            Text("\(channelCount) channels")
                                .font(.caption2)
                                .fontWeight(.medium)
                                .foregroundColor(.secondary)
                            Text("• Expand preview to see individual lanes")
                                .font(.caption2)
                                .foregroundColor(.secondary.opacity(0.7))
                        }
                        .frame(height: 14)
                    }
                }
            }
            // Set preferred height based on channel count
            .frame(minHeight: 50, idealHeight: CGFloat(channelCount) * (channelCount <= 2 ? 25 : 14))
        } else {
            // Mono: fixed height single waveform
            waveformView
                .frame(height: 50)
        }
    }
    
    // MARK: - Waveform View with Real-Time Playhead
    
    private var waveformView: some View {
        GeometryReader { geometry in
            ZStack {
                // Background
                RoundedRectangle(cornerRadius: 4)
                    .fill(Color(NSColor.textBackgroundColor))
                
                if playbackManager.isGeneratingWaveform {
                    HStack(spacing: 8) {
                        ProgressView()
                            .scaleEffect(0.7)
                        Text("Loading...")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                    }
                    .transition(.identity)  // Disable animation to prevent bouncing/vibrating
                    .animation(.none, value: playbackManager.isGeneratingWaveform)
                } else if playbackManager.waveformData.isEmpty && !playbackManager.waveformError {
                    Text("No waveform")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                } else if playbackManager.waveformError {
                    HStack(spacing: 4) {
                        Image(systemName: "exclamationmark.triangle")
                            .foregroundColor(.orange)
                        Text("Waveform unavailable")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                    }
                } else {
                    // Real-time waveform with playhead
                    TimelineView(.animation(minimumInterval: 0.05)) { _ in
                        Canvas { context, size in
                            let barWidth = size.width / CGFloat(playbackManager.waveformData.count)
                            let midY = size.height / 2
                            
                            // Calculate current progress
                            let progress = playbackManager.engine.duration > 0 
                                ? playbackManager.engine.currentTime / playbackManager.engine.duration 
                                : 0
                            
                            for (index, amplitude) in playbackManager.waveformData.enumerated() {
                                let x = CGFloat(index) * barWidth
                                let barHeight = CGFloat(amplitude) * size.height * 0.9
                                
                                let rect = CGRect(
                                    x: x,
                                    y: midY - barHeight / 2,
                                    width: max(1, barWidth - 1),
                                    height: max(1, barHeight)
                                )
                                
                                // Played portion is brighter
                                let isPlayed = CGFloat(index) / CGFloat(playbackManager.waveformData.count) < progress
                                
                                context.fill(
                                    Path(roundedRect: rect, cornerRadius: 1),
                                    with: .color(isPlayed ? .accentColor : .accentColor.opacity(0.4))
                                )
                            }
                            
                            // Playhead line
                            if playbackManager.engine.duration > 0 && progress > 0 {
                                let playheadX = CGFloat(progress) * size.width
                                
                                var path = Path()
                                path.move(to: CGPoint(x: playheadX, y: 0))
                                path.addLine(to: CGPoint(x: playheadX, y: size.height))
                                
                                context.stroke(path, with: .color(.white), lineWidth: 2)
                            }
                        }
                    }
                    .gesture(
                        DragGesture(minimumDistance: 0)
                            .onChanged { value in
                                let percent = max(0, min(1, value.location.x / geometry.size.width))
                                playbackManager.seekToPercent(percent)
                            }
                    )
                }
            }
        }
    }
    
    // MARK: - Multi-Channel Waveform View (Stacked Lanes)
    
    private var multiChannelWaveformView: some View {
        GeometryReader { geometry in
            ZStack {
                // Background
                RoundedRectangle(cornerRadius: 4)
                    .fill(Color(NSColor.textBackgroundColor))
                
                if playbackManager.isGeneratingWaveform {
                    HStack(spacing: 8) {
                        ProgressView()
                            .scaleEffect(0.7)
                        Text("Loading channels...")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                    }
                    .transition(.identity)  // Disable animation to prevent bouncing/vibrating
                    .animation(.none, value: playbackManager.isGeneratingWaveform)
                } else if playbackManager.multiChannelWaveformData.isEmpty && !playbackManager.waveformError {
                    Text("No waveform")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                } else if playbackManager.waveformError {
                    HStack(spacing: 4) {
                        Image(systemName: "exclamationmark.triangle")
                            .foregroundColor(.orange)
                        Text("Waveform unavailable")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                    }
                } else {
                    // Stacked waveform lanes with shared playhead
                    TimelineView(.animation(minimumInterval: 0.05)) { _ in
                        Canvas { context, size in
                            let channelCount = playbackManager.multiChannelWaveformData.count
                            guard channelCount > 0 else { return }
                            
                            let laneHeight = size.height / CGFloat(channelCount)
                            let channelTags = playbackManager.availableChannelTags
                            
                            // Calculate current progress
                            let progress = playbackManager.engine.duration > 0
                                ? playbackManager.engine.currentTime / playbackManager.engine.duration
                                : 0
                            
                            // Draw each channel lane
                            for (channelIndex, channelData) in playbackManager.multiChannelWaveformData.enumerated() {
                                let laneY = CGFloat(channelIndex) * laneHeight
                                let midY = laneY + laneHeight / 2
                                
                                // Determine if this channel is currently selected
                                let channelTag = channelIndex < channelTags.count ? channelTags[channelIndex] : nil
                                let isSelected = channelTag != nil && playbackManager.selectedChannelTag == channelTag
                                let isMixMode = playbackManager.selectedChannelTag == nil
                                
                                // Draw lane separator (subtle line between lanes)
                                if channelIndex > 0 {
                                    var separatorPath = Path()
                                    separatorPath.move(to: CGPoint(x: 0, y: laneY))
                                    separatorPath.addLine(to: CGPoint(x: size.width, y: laneY))
                                    context.stroke(separatorPath, with: .color(Color.secondary.opacity(0.2)), lineWidth: 0.5)
                                }
                                
                                // Draw channel label on the left
                                if let tag = channelTag {
                                    let labelRect = CGRect(x: 2, y: laneY + 1, width: 20, height: laneHeight - 2)
                                    context.draw(
                                        Text(tag)
                                            .font(.system(size: 7, weight: .medium))
                                            .foregroundColor(isSelected ? .orange : .secondary),
                                        in: labelRect
                                    )
                                }
                                
                                // Draw waveform bars for this channel
                                let barWidth = (size.width - 22) / CGFloat(channelData.count)  // Leave space for label
                                let waveformStartX: CGFloat = 22
                                
                                for (index, amplitude) in channelData.enumerated() {
                                    let x = waveformStartX + CGFloat(index) * barWidth
                                    let barHeight = CGFloat(amplitude) * (laneHeight - 2) * 0.9
                                    
                                    let rect = CGRect(
                                        x: x,
                                        y: midY - barHeight / 2,
                                        width: max(1, barWidth - 0.5),
                                        height: max(1, barHeight)
                                    )
                                    
                                    // Color logic:
                                    // - Selected channel: orange (bright when played, dimmer when not)
                                    // - Mix mode: all channels blue
                                    // - Other channels when one is selected: dimmed blue
                                    let isPlayed = CGFloat(index) / CGFloat(channelData.count) < progress
                                    
                                    let barColor: Color
                                    if isSelected {
                                        barColor = isPlayed ? .orange : .orange.opacity(0.5)
                                    } else if isMixMode {
                                        barColor = isPlayed ? .accentColor : .accentColor.opacity(0.4)
                                    } else {
                                        // Another channel is selected, dim this one
                                        barColor = isPlayed ? .accentColor.opacity(0.3) : .accentColor.opacity(0.15)
                                    }
                                    
                                    context.fill(
                                        Path(roundedRect: rect, cornerRadius: 0.5),
                                        with: .color(barColor)
                                    )
                                }
                            }
                            
                            // Shared playhead line across all lanes
                            if playbackManager.engine.duration > 0 && progress > 0 {
                                let playheadX: CGFloat = 22 + CGFloat(progress) * (size.width - 22)
                                
                                var playheadPath = Path()
                                playheadPath.move(to: CGPoint(x: playheadX, y: 0))
                                playheadPath.addLine(to: CGPoint(x: playheadX, y: size.height))
                                
                                context.stroke(playheadPath, with: .color(.white), lineWidth: 1.5)
                            }
                        }
                    }
                    .gesture(
                        DragGesture(minimumDistance: 0)
                            .onChanged { value in
                                // Adjust for label offset
                                let adjustedX = value.location.x - 22
                                let adjustedWidth = geometry.size.width - 22
                                let percent = max(0, min(1, adjustedX / adjustedWidth))
                                playbackManager.seekToPercent(percent)
                            }
                    )
                }
            }
        }
    }
    
    // MARK: - Helpers
    
    private func formatTime(_ time: TimeInterval) -> String {
        let minutes = Int(time) / 60
        let seconds = Int(time) % 60
        return String(format: "%d:%02d", minutes, seconds)
    }
}

// MARK: - Preview
#Preview {
    AudioPreviewPanel(playbackManager: PlaybackManager())
        .frame(width: 600, height: 140)
        .padding()
}
