// SimplePlaybackTransport.swift
// AudioInterleaver
// Simple playback transport for Stereo Validator - no waveforms, just play/pause/seek

import SwiftUI

/// A minimal playback transport bar: Play/Pause + Filename + Scrubber + Time
/// Used in Stereo Validator for quick file audition
struct SimplePlaybackTransport: View {
    @ObservedObject var playbackManager: PlaybackManager
    let fileName: String
    
    // Fixed height
    private let transportHeight: CGFloat = 36
    
    var body: some View {
        HStack(spacing: 12) {
            // Play/Pause button
            Button(action: {
                playbackManager.togglePlayPause()
            }) {
                Image(systemName: playbackManager.isPlaying ? "pause.fill" : "play.fill")
                    .font(.system(size: 14))
                    .frame(width: 28, height: 28)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .disabled(!playbackManager.isLoaded)
            .help(playbackManager.isPlaying ? "Pause (Space)" : "Play (Space)")
            
            // Stop button
            Button(action: {
                playbackManager.stop()
            }) {
                Image(systemName: "stop.fill")
                    .font(.system(size: 12))
                    .frame(width: 24, height: 24)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .disabled(!playbackManager.isLoaded)
            .help("Stop")
            
            // Filename
            Text(fileName)
                .font(.caption)
                .lineLimit(1)
                .truncationMode(.middle)
                .frame(minWidth: 100, maxWidth: 200, alignment: .leading)
                .foregroundColor(.primary)
            
            // Progress slider
            Slider(
                value: Binding(
                    get: { 
                        guard playbackManager.engine.duration > 0 else { return 0 }
                        return playbackManager.engine.currentTime / playbackManager.engine.duration
                    },
                    set: { newValue in
                        playbackManager.seekToPercent(newValue)
                    }
                ),
                in: 0...1
            )
            .disabled(!playbackManager.isLoaded)
            .help("Scrub playback position (⌘← ⌘→ to jump)")
            
            // Time display
            HStack(spacing: 2) {
                Text(formatTime(playbackManager.engine.currentTime))
                    .monospacedDigit()
                Text("/")
                    .foregroundColor(.secondary)
                Text(formatTime(playbackManager.engine.duration))
                    .monospacedDigit()
            }
            .font(.caption)
            .foregroundColor(.secondary)
            .frame(width: 90, alignment: .trailing)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .frame(height: transportHeight)
        .background(Color(NSColor.controlBackgroundColor))
        .cornerRadius(6)
    }
    
    // MARK: - Helpers
    
    private func formatTime(_ seconds: Double) -> String {
        guard seconds.isFinite && seconds >= 0 else { return "0:00" }
        let mins = Int(seconds) / 60
        let secs = Int(seconds) % 60
        return String(format: "%d:%02d", mins, secs)
    }
}

// MARK: - Preview

#Preview {
    VStack {
        SimplePlaybackTransport(
            playbackManager: PlaybackManager(),
            fileName: "CCR BEAT v2.wav"
        )
        .padding()
    }
    .frame(width: 500)
}
