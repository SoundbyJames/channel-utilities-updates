// PolyToolsPlaybackTransport.swift
// AudioInterleaver
// Playback transport for Poly Tools - supports single file and mix preview

import SwiftUI

/// Playback transport for Poly Tools with channel indicator
struct PolyToolsPlaybackTransport: View {
    @ObservedObject var mixer: PreviewMixer
    let displayLabel: String  // "BOOM.wav" or "Preview Mix: 3 ISOs"
    
    /// Currently active channel number from metadata (nil = playing poly source)
    var activeChannelNumber: Int? = nil
    
    /// Whether we're playing the original poly (ground truth) vs extracted ISOs
    var isPolyPlayback: Bool = false
    
    // Fixed height
    private let transportHeight: CGFloat = 36
    
    var body: some View {
        HStack(spacing: 12) {
            // Play/Pause button
            Button(action: {
                if mixer.isPlaying {
                    mixer.pause()
                } else {
                    mixer.play()
                }
            }) {
                Image(systemName: mixer.isPlaying ? "pause.fill" : "play.fill")
                    .font(.system(size: 14))
                    .frame(width: 28, height: 28)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .disabled(!mixer.isLoaded)
            .help(mixer.isPlaying ? "Pause (Space)" : "Play (Space)")
            
            // Stop button
            Button(action: {
                mixer.stop()
            }) {
                Image(systemName: "stop.fill")
                    .font(.system(size: 12))
                    .frame(width: 24, height: 24)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .disabled(!mixer.isLoaded)
            .help("Stop")
            
            // Channel / Poly indicator badge (non-clickable, informational)
            if mixer.isLoaded {
                if isPolyPlayback {
                    // Playing the original poly file
                    HStack(spacing: 4) {
                        Image(systemName: "waveform.path")
                            .font(.caption)
                        Text("POLY")
                            .font(.caption.bold())
                    }
                    .foregroundColor(.green)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 2)
                    .background(Color.green.opacity(0.15))
                    .cornerRadius(4)
                    .help("Playing original poly file")
                } else if let chNum = activeChannelNumber {
                    // Playing an extracted ISO channel
                    HStack(spacing: 4) {
                        Image(systemName: "speaker.wave.2")
                            .font(.caption)
                        Text("T\(chNum)")
                            .font(.caption.bold())
                    }
                    .foregroundColor(.orange)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 2)
                    .background(Color.orange.opacity(0.15))
                    .cornerRadius(4)
                    .help("Listening to channel T\(chNum)")
                }
            }
            
            // Display label
            Text(displayLabel)
                .font(.caption)
                .lineLimit(1)
                .truncationMode(.middle)
                .frame(minWidth: 100, maxWidth: 200, alignment: .leading)
                .foregroundColor(mixer.isLoaded ? .primary : .secondary)
            
            // Progress slider
            Slider(
                value: Binding(
                    get: { 
                        guard mixer.duration > 0 else { return 0 }
                        return mixer.currentTime / mixer.duration
                    },
                    set: { newValue in
                        mixer.seekToPercent(newValue)
                    }
                ),
                in: 0...1
            )
            .disabled(!mixer.isLoaded)
            .help("Scrub playback position")
            
            // Time display
            HStack(spacing: 2) {
                Text(formatTime(mixer.currentTime))
                    .monospacedDigit()
                Text("/")
                    .foregroundColor(.secondary)
                Text(formatTime(mixer.duration))
                    .monospacedDigit()
            }
            .font(.caption)
            .foregroundColor(.secondary)
            .frame(width: 90, alignment: .trailing)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .frame(height: transportHeight)
        .background(Color(NSColor.controlBackgroundColor))
        .cornerRadius(6)
    }
    
    // MARK: - Helpers
    
    private func formatTime(_ seconds: Double) -> String {
        guard seconds.isFinite && seconds >= 0 else { return "0:00" }
        let mins = Int(seconds) / 60
        let secs = Int(seconds) % 60
        return String(format: "%d:%02d", mins, secs)
    }
}

// MARK: - Preview

#Preview {
    VStack(spacing: 20) {
        // Single file mode
        PolyToolsPlaybackTransport(
            mixer: PreviewMixer(),
            displayLabel: "9CT01_BOOM.wav"
        )
        
        // ISO channel mode
        PolyToolsPlaybackTransport(
            mixer: PreviewMixer(),
            displayLabel: "9CT01_BOOM.wav",
            activeChannelNumber: 6
        )
        
        // Poly playback mode
        PolyToolsPlaybackTransport(
            mixer: PreviewMixer(),
            displayLabel: "9CT01.wav",
            isPolyPlayback: true
        )
    }
    .padding()
    .frame(width: 500)
}
